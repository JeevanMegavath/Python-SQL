# Databricks notebook source
# DBTITLE 1,Manager Team Sizes
# MAGIC %sql
# MAGIC -- Step 1: Create managers table
# MAGIC CREATE TABLE managers (
# MAGIC     id INTEGER PRIMARY KEY,
# MAGIC     name VARCHAR(255),
# MAGIC     team VARCHAR(255)
# MAGIC );
# MAGIC
# MAGIC -- Step 2: Create employees table
# MAGIC CREATE TABLE employees (
# MAGIC     id INTEGER PRIMARY KEY,
# MAGIC     name VARCHAR(255),
# MAGIC     manager_id INTEGER,
# MAGIC     FOREIGN KEY (manager_id) REFERENCES managers(id)
# MAGIC );
# MAGIC
# MAGIC -- Step 3: Populate tables with sample data
# MAGIC INSERT INTO managers (id, name, team) VALUES
# MAGIC     (1, 'Manager A', 'Team A'),
# MAGIC     (2, 'Manager B', 'Team B');
# MAGIC
# MAGIC INSERT INTO employees (id, name, manager_id) VALUES
# MAGIC     (1, 'Employee 1', 1),
# MAGIC     (2, 'Employee 2', 1),
# MAGIC     (3, 'Employee 3', 2),
# MAGIC     (4, 'Employee 4', 2),
# MAGIC     (5, 'Employee 5', 2);
# MAGIC
# MAGIC -- Step 4: Write a query to identify the manager with the biggest team size
# MAGIC SELECT m.name AS manager, COUNT(e.id) AS team_size
# MAGIC FROM managers m
# MAGIC LEFT JOIN employees e ON m.id = e.manager_id
# MAGIC GROUP BY m.id
# MAGIC ORDER BY team_size DESC
# MAGIC LIMIT 1;
# MAGIC

# COMMAND ----------

