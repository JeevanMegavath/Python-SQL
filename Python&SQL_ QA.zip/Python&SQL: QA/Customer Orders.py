# Databricks notebook source
'''
Given a table of transactions and a table of users, write a query to determine if users tend to order more to their primary address versus other addresses.

Note: Return the percentage of transactions ordered to their home address as home_address_percent.

Example:

Input:

transactions table:

Columns	Type
id	INTEGER
user_id	INTEGER
created_at	DATETIME
shipping_address	VARCHAR
users table:

Columns	Type
id	INTEGER
name	VARCHAR
address	VARCHAR
Example Output:

home_address_percent	0.76
'''

# COMMAND ----------

# MAGIC %sql
# MAGIC Select avg(case when t.user_id = u.id then 1 else 0 end) as home_address_percent
# MAGIC from transactions t join users u
# MAGIC on t.user_id = u.id

# COMMAND ----------

# MAGIC %sql
# MAGIC Write a query to identify customers who placed more than three transactions each in both 2019 and 2020.
# MAGIC
# MAGIC Example:
# MAGIC
# MAGIC Input:
# MAGIC
# MAGIC transactions table
# MAGIC
# MAGIC Column	Type
# MAGIC id	INTEGER
# MAGIC user_id	INTEGER
# MAGIC created_at	DATETIME
# MAGIC product_id	INTEGER
# MAGIC quantity	INTEGER
# MAGIC users table
# MAGIC
# MAGIC Column	Type
# MAGIC id	INTEGER
# MAGIC name	VARCHAR
# MAGIC   Output:
# MAGIC
# MAGIC Column	Type
# MAGIC customer_name	VARCHAR

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the users table
# MAGIC CREATE TABLE users (
# MAGIC     id INTEGER PRIMARY KEY,
# MAGIC     name VARCHAR(255)
# MAGIC );
# MAGIC
# MAGIC -- Insert data into the users table
# MAGIC INSERT INTO users (id, name) VALUES
# MAGIC (1, 'Om Crosby'),
# MAGIC (2, 'Rhydian Orozco'),
# MAGIC (3, 'Nishat Goodman'),
# MAGIC (4, 'Mikael Golden');
# MAGIC
# MAGIC -- Create the transactions table
# MAGIC CREATE TABLE transactions (
# MAGIC     id INT PRIMARY KEY IDENTITY,
# MAGIC     user_id INT,
# MAGIC     created_at DATETIME,
# MAGIC     product_id INT,
# MAGIC     quantity INT,
# MAGIC     FOREIGN KEY (user_id) REFERENCES users(id)
# MAGIC );
# MAGIC
# MAGIC -- Insert data into the transactions table
# MAGIC INSERT INTO transactions (user_id, created_at, product_id, quantity) VALUES
# MAGIC (1, '2019-01-27 00:00:00', 1, 50),
# MAGIC (1, '2019-01-24 00:00:00', 2, 100),
# MAGIC (1, '2019-01-25 00:00:00', 3, 305),
# MAGIC (1, '2019-01-26 00:00:00', 4, 75),
# MAGIC (1, '2020-03-24 00:00:00', 5, 415),
# MAGIC (1, '2020-03-25 00:00:00', 6, 285),
# MAGIC (1, '2020-03-26 00:00:00', 7, 175),
# MAGIC (1, '2020-03-27 00:00:00', 8, 35),
# MAGIC (2, '2019-05-09 00:00:00', 1, 150),
# MAGIC (2, '2019-05-10 00:00:00', 10, 250),
# MAGIC (3, '2019-07-23 00:00:00', 2, 100),
# MAGIC (3, '2019-07-24 00:00:00', 3, 85),
# MAGIC (3, '2019-07-25 00:00:00', 4, 255),
# MAGIC (3, '2019-07-26 00:00:00', 5, 300),
# MAGIC (3, '2020-12-23 00:00:00', 11, 105),
# MAGIC (3, '2020-12-24 00:00:00', 12, 110),
# MAGIC (3, '2020-12-25 00:00:00', 13, 235),
# MAGIC (3, '2020-12-26 00:00:00', 14, 90),
# MAGIC (4, '2020-10-20 00:00:00', 1, 50),
# MAGIC (4, '2020-10-21 00:00:00', 2, 50),
# MAGIC (4, '2020-10-22 00:00:00', 3, 50);
# MAGIC
# MAGIC >>>>>>>>>>>>>>>>
# MAGIC -- Query to identify customers who placed more than three transactions each in both 2019 and 2020
# MAGIC >>>>>>>>>>>>>>>>>
# MAGIC
# MAGIC WITH YearlyTransactionCounts AS (
# MAGIC     SELECT
# MAGIC         u.name AS customer_name,
# MAGIC         YEAR(t.created_at) AS transaction_year,
# MAGIC         COUNT(*) AS transaction_count
# MAGIC     FROM users u JOINb transactions t ON u.id = t.user_id
# MAGIC     WHERE
# MAGIC         YEAR(t.created_at) IN (2019, 2020)
# MAGIC     GROUP BY
# MAGIC         u.id, u.name, YEAR(t.created_at)
# MAGIC     HAVING
# MAGIC         COUNT(*) > 3
# MAGIC ),
# MAGIC CustomerYears AS (
# MAGIC     SELECT customer_name FROM YearlyTransactionCounts
# MAGIC     GROUP BY
# MAGIC         customer_name
# MAGIC     HAVING
# MAGIC         COUNT(DISTINCT transaction_year) = 2
# MAGIC )
# MAGIC SELECT customer_name FROM CustomerYears;
# MAGIC

# COMMAND ----------

'''Write a query to identify customers who placed more than three transactions each in both 2019 and 2020.'''

with cte as(
select u.id, name, year(created_at) as Year, product_id, quantity from users u join transaction1 t
on u.id = t.user_id
where year(created_at) in ('2019', '2020')
)
select name from cte
group by name
having count(*)>3