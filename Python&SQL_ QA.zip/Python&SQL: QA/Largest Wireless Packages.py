# Databricks notebook source
# MAGIC %sql
# MAGIC The table packet_rates contains data about wireless packages sent from multiple devices to different networks (SSID).
# MAGIC
# MAGIC Write a query that returns, for each SSID, the largest number of packages sent by a single device in the first 10 minutes of January 1st, 2022.
# MAGIC
# MAGIC Example:
# MAGIC
# MAGIC Input:
# MAGIC
# MAGIC packet_rates table
# MAGIC
# MAGIC Column	Type
# MAGIC packet_id	INTEGER
# MAGIC ssid	VARCHAR
# MAGIC mac_address	VARCHAR
# MAGIC time_captured	DATETIME
# MAGIC packet_size	INTEGER
# MAGIC Output:
# MAGIC
# MAGIC Column	Type
# MAGIC ssid	VARCHAR
# MAGIC max_number_of_packages_sent	INTEGER

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH cte AS (
# MAGIC     SELECT ssid, mac_address, COUNT(*) AS number_of_packets_sent
# MAGIC     FROM packet_rates
# MAGIC     WHERE time_captured < '2022-01-01 00:10:00'
# MAGIC     GROUP BY ssid, mac_address
# MAGIC )
# MAGIC SELECT ssid, MAX(number_of_packets_sent) AS max_number_of_packages_sent
# MAGIC FROM cte
# MAGIC GROUP BY ssid;
# MAGIC
# MAGIC
# MAGIC select ssid, max(number_of_packets_sent) as max_number_of_packages_sen FROM 
# MAGIC (
# MAGIC SELECT ssid, mac_address, count(*) as number_of_packets_sent
# MAGIC from packet_rates
# MAGIC where time_captured < '2022-01-01 00:10:00'
# MAGIC group by ssid, mac_address
# MAGIC ) as packate_sents
# MAGIC GROUP BY ssid;

# COMMAND ----------

