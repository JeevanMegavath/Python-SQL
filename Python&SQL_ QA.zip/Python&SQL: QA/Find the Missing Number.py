# Databricks notebook source
def missing_number(nums):
    n = int(nums[-1])
    print(n)
    expected_number = n*(n+1)//2
    actual_number = sum(nums)
    return expected_number - actual_number

nums = [1,2,4,8]
print(missing_number(nums))  

# COMMAND ----------

nums = [0,1,2,4,5]

l = len(nums)
m = 0
for i in nums:
  m = m + i
print(m)
y = l * (l + 1) // 2
print(y)
missing_number = y - m
print(int(missing_number))


# COMMAND ----------

# Summation Method
def missing_number_sum(nums):
    n = len(nums)
    expected_sum = n * (n + 1) // 2
    actual_sum = sum(nums)
    return expected_sum - actual_sum

# XOR Method
def missing_number_xor(nums):
    missing = len(nums)
    for i, num in enumerate(nums):
        missing ^= i ^ num
    return missing

# Set Difference Method
def missing_number_set_difference(nums):
    n = len(nums)
    return (set(range(n + 1)) - set(nums)).pop()

# Sorting Method
def missing_number_sort(nums):
    nums.sort()
    for i, num in enumerate(nums):
        if i != num:
            return i
    return len(nums)

# Arithmetic Progression Method
def missing_number_arithmetic(nums):
    n = len(nums)
    expected_sum = n * (n + 1) // 2
    actual_sum = sum(nums)
    return expected_sum - actual_sum

# Example usage:
nums = [0, 1, 2, 4, 5]

print("Summation Method:", missing_number_sum(nums))
print("XOR Method:", missing_number_xor(nums))
print("Set Difference Method:", missing_number_set_difference(nums))
print("Sorting Method:", missing_number_sort(nums))
print("Arithmetic Progression Method:", missing_number_arithmetic(nums))


# COMMAND ----------

def missing_number_set_difference(nums):
    n = len(nums)
    s = set(range(n + 1))
    print(s)
    y = set(nums)
    print(y)
    m = (s- y)
    print(m)
    m = m.pop()
    print(m)
    return m
print("Set Difference Method:", missing_number_set_difference(nums))


# COMMAND ----------

nums = [0,1,3,4,5]

def missing_Number(nums):
    n = len(nums)
    return (set(range(n+1))-set(nums)).pop()

print("MIssing Number is: ", missing_Number(nums))

# COMMAND ----------

def missing_number_sort(nums):
    nums.sort()
    for i, num in enumerate(nums):
        if i!=num:
            return i
    
   # we removed the return len(nums)

print("MIssing Number is: ", missing_number_sort(nums))

# COMMAND ----------

