# Databricks notebook source
# DBTITLE 1,Empty Neighborhoods   
#  https://www.interviewquery.com/questions/empty-neighborhoodsd

'''We’re given two tables, a users table with demographic information and the neighborhood they live in and a neighborhoods table.##

Write a query that returns all neighborhoods that have 0 users. 

Example:

Input:

users table

Columns	Type
id	INTEGER
name	VARCHAR
neighborhood_id	INTEGER
created_at	DATETIME

neighborhoods table

Columns	Type
id	INTEGER
name	VARCHAR
city_id	INTEGER

Output:
Columns	Type
https://www.interviewquery.com/questions/empty-neighborhoodsdname	VARCHAR'''

# COMMAND ----------

# We’re given two tables, a users table with demographic information and the neighborhood they live in and a neighborhoods table.

# Write a query that returns all neighborhoods that have 0 users

# COMMAND ----------

# DBTITLE 1,The Answer 
# MAGIC %sql
# MAGIC
# MAGIC SELECT n.name from neighborhoods n
# MAGIC LEFT JOIN users u
# MAGIC on n.id = u.neighborhood_id
# MAGIC group by n.id
# MAGIC having count(users.id)= 0;

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS users (
# MAGIC   id INTEGER,
# MAGIC   name VARCHAR(50),
# MAGIC   neighborhood_id INTEGER,
# MAGIC   created_at DATE
# MAGIC );
# MAGIC
# MAGIC desc users

# COMMAND ----------

# MAGIC %sql
# MAGIC /* INSERT into users(id, name, neighborhood_id) over(1, "Jeevan", 5 )
# MAGIC
# MAGIC #INSERT INTO users (id, name, neighborhood_id)
# MAGIC #VALUES (1, 'Jeevan', 5);*/
# MAGIC
# MAGIC INSERT INTO users (id, name, neighborhood_id, created_at) VALUES (11, 'Jeevan', 5, current_date);
# MAGIC
# MAGIC select * from users

# COMMAND ----------



# COMMAND ----------

